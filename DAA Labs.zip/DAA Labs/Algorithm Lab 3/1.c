// Write a program in C to implement fractional knapsack. Assume that the
// arrays p[] and w[] have items sorted by decreasing pi/wi ratios.

#include <stdio.h>

void fK(int n, float p[], float w[], float cap) {
    float x[n], total = 0;
    int i;
    for (i = 0; i < n; i++) {
        x[i] = 0.0;
    }

    for (i = 0; i < n; i++) {
        if (w[i] > cap) {
            break;
        } else {
            x[i] = 1.0;
            total += p[i];
            cap -= w[i];
        }
    }

    if (i < n) {
        x[i] = cap / w[i];
        total += x[i] * p[i];
    }

    printf("The result is: ");
    for (i = 0; i < n; i++) {
        printf("%f ", x[i]);
    }

    printf("\nMax profit is: %f\n", total);
}

int main() {
    int n = 3;
    float p[] = {60, 100, 120};
    float w[] = {10, 20, 30};
    float cap = 50;

    fK(n, p, w, cap);

    return 0;
}
