def ks_bott(item_weights, item_values, max_capacity):
    num_items = len(item_weights)
    dp_table = [[0 for _ in range(max_capacity + 1)] for _ in range(num_items + 1)]
    
    for item in range(1, num_items + 1):
        for capacity in range(max_capacity + 1):
            if item_weights[item - 1] <= capacity:
                dp_table[item][capacity] = max(
                    dp_table[item - 1][capacity],
                    item_values[item - 1] + dp_table[item - 1][capacity - item_weights[item - 1]]
                )
            else:
                dp_table[item][capacity] = dp_table[item - 1][capacity]
    
    return dp_table

def sel_items(dp_table, item_weights, item_values, max_capacity):
    num_items = len(item_weights)
    chosen_items = []
    rem_capacity = max_capacity
    
    for item in range(num_items, 0, -1):
        if dp_table[item][rem_capacity] != dp_table[item - 1][rem_capacity]:
            chosen_items.append((item_weights[item - 1], item_values[item - 1]))
            rem_capacity -= item_weights[item - 1]
    
    return chosen_items

weights = [3, 2, 2]
values = [1.5, 1, 1]
capacity = 4

dp_table = ks_bott(weights, values, capacity)
selected_items = sel_items(dp_table, weights, values, capacity)

print("Maximum value :", dp_table[len(weights)][capacity])
print("Selected (weight, value):", selected_items)