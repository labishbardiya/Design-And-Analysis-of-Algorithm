def binary_search(intervals, current_index):
    low, high = 0, current_index - 1
    while low <= high:
        mid = (low + high) // 2
        if intervals[mid][1] <= intervals[current_index][0]:
            if intervals[mid + 1][1] <= intervals[current_index][0]:
                low = mid + 1
            else:
                return mid
        else:
            high = mid - 11
    return -1

def weighted_scheduling(intervals):
    for i in range(len(intervals)):
        for j in range(i + 1, len(intervals)):
            if intervals[i][1] > intervals[j][1]:
                intervals[i], intervals[j] = intervals[j], intervals[i]
    
    num_intervals = len(intervals)
    previous_compatible = [0] * num_intervals
    max_weights = [0] * num_intervals
    
    for i in range(num_intervals):
        previous_compatible[i] = binary_search(intervals, i)
    
    max_weights[0] = intervals[0][2]
    
    for i in range(1, num_intervals):
        include_weight = intervals[i][2]
        if previous_compatible[i] != -1:
            include_weight += max_weights[previous_compatible[i]]
        max_weights[i] = max(include_weight, max_weights[i - 1])
    
    return max_weights, intervals, previous_compatible

def select_intervals(max_weights, intervals, previous_compatible):
    current_index = len(intervals) - 1
    selected_intervals = []
    
    while current_index >= 0:
        if current_index == 0 or max_weights[current_index] != max_weights[current_index - 1]:
            selected_intervals.append(intervals[current_index])
            current_index = previous_compatible[current_index]
        else:
            current_index -= 1
    
    return selected_intervals[::-1]

intervals = [(0, 3, 3), (1, 4, 2), (0, 5, 4), (3, 6, 1), (4, 7, 2), (3, 9, 5), (5, 10, 2), (8, 10, 1)]
max_weights, sorted_intervals, previous_compatible = weighted_scheduling(intervals)
selected_intervals = select_intervals(max_weights, sorted_intervals, previous_compatible)

print("Max weight:", max_weights[-1])
print("Selected intervals:", selected_intervals)
