class Graph:
    def __init__(self, vertices):
        self.V = vertices
        self.graph = []

    def add_edge(self, u, v, w):
        self.graph.append([u, v, w])

    def bellman_ford(self, src):
        dist = [float("Inf")] * self.V
        dist[src] = 0

        for i in range(self.V - 1):
            for u, v, w in self.graph:
                if dist[u] != float("Inf") and dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w

        for u, v, w in self.graph:
            if dist[u] != float("Inf") and dist[u] + w < dist[v]:
                print("Graph have negative weight cycle")
                return

        self.print_solution(dist)

    def print_solution(self, dist):
        print("Vertex Distance from Source")
        for i in range(self.V):
            print(f"{i}\t\t{dist[i]}")


g = Graph(5)
g.add_edge(0, 1, 3)
g.add_edge(0, 2, 8)
g.add_edge(0, 4, -4)
g.add_edge(1, 4, 7)
g.add_edge(1, 3, 1)
g.add_edge(2, 1, 4)
g.add_edge(3, 2, -5)
g.add_edge(3, 0, 2)
g.add_edge(4, 3, 6)

g.bellman_ford(0)
