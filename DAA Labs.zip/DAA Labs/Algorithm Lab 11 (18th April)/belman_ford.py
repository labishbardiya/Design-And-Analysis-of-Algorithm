def is_neg_cycle_bf(vertices, edges, src, dist, visited):
    dist[src] = 0

    for _ in range(vertices - 1):
        for u, v, w in edges:
            if dist[u] != float('inf') and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w

    for u, v, w in edges:
        if dist[u] != float('inf') and dist[u] + w < dist[v]:
            return True

    for i in range(vertices):
        if dist[i] != float('inf'):
            visited[i] = True
    return False

def is_neg_cycle(vertices, edges):
    visited = [False] * vertices
    dist = [float('inf')] * vertices

    for i in range(vertices):
        if not visited[i]:
            if is_neg_cycle_bf(vertices, edges, i, dist, visited):
                return True
    return False

vertices = 3
edges = []
edges.append((0, 1, 1))
edges.append((1, 2, 2))
edges.append((2, 0, -2))
print(edges)

if is_neg_cycle(vertices, edges):
    print("Yes")
else:
    print("No")
