from collections import deque

def is_bipartite(graph, V):
    color = [None] * V
    
    for start in range(V):
        if color[start] is None:
            queue = deque([start])
            color[start] = 0
            
            while queue:
                node = queue.popleft()
                
                for neighbor in graph[node]:
                    if color[neighbor] is None:
                        color[neighbor] = 1 - color[node]
                        queue.append(neighbor)
                    elif color[neighbor] == color[node]:
                        return False
            
    return True

graph = {
    0: [1, 2],
    1: [1, 3],
    2: [1, 3],
}

V = 3

if is_bipartite(graph, V):
    print("The graph is bipartite.")
else:
    print("The graph is not bipartite.")
