# Sort a given set of elements using the two codes given below. The elements can be read
# from a file or can be generated using the random number generator.

def sort1(arr, n):
    if n > 0:
        sort1(arr, n - 1)
        x = arr[n]
        j = n - 1
        while j >= 0 and arr[j] > x:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = x
    return arr

arr = []
n = int(input("Enter the number of elements: "))

for i in range(n):
    arr.append(int(input("Enter an element: ")))

arr = sort1(arr, n - 1)
print(arr)

# a) Determine the time required to sort the elements.

# Complexity is of the order O(n^2)

# b) Repeat the experiment for different values of n, the number of elements in the list to
# be sorted. n can be varied from 2, 100, 1000, 10000, 1000000.

# if n = 2 then time required is O(4)
# if n = 100 then time required is O(10000)
# if n = 1000 then time required is O(1000000)
# if n = 10000 then time required is O(100000000)
# if n = 100000 then time required is O(10000000000)
