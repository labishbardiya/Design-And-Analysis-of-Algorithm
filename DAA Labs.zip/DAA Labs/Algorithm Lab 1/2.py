# Given an array of n distinct numbers. The task is to sort numbers in an even index in
# increasing order and those in an odd index in a decreasing order. The modified array should
# represent the same. It may be assumed that elements in both arrays are distinct.

arr = []
n = int(input("Enter the number of elements: "))
for i in range(n):
    arr.append(int(input("Enter an element: ")))

even = []
odd = []

for i in range(n):
    if i % 2 == 0:
        even.append(arr[i])
    else:
        odd.append(arr[i])

even.sort()
odd.sort(reverse=True)

for i in range(n):
    if i % 2 == 0:
        arr[i] = even[i // 2]
    else:
        arr[i] = odd[i // 2]

print("Modified Array:", arr)
