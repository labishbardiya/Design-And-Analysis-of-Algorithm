# c) Plot a graph of the time taken versus n.

import numpy as np
import matplotlib.pyplot as plt

def f(x):
    return x**2

x = np.linspace(-5, 50, 100)

t = f(x)

n = [2, 100, 1000, 10000, 100000]
t = [4, 10000, 1000000, 100000000, 10000000000]

plt.plot(n, t)
plt.xlabel('n')
plt.ylabel('t')
plt.title('Plot of time taken & no. of elements in the set: ')
plt.grid(True)
plt.show()
