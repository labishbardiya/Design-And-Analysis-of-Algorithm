# Given two arrays: arr1 of size n and arr2 of size m. Find whether arr2 is a subset of arr1.
# Both the arrays are NOT sorted. It may be assumed that elements in both arrays are distinct.

arr1 = []
n = int(input("Enter the number of elements: "))
for i in range(n):
    arr1.append(int(input("Enter the element: ")))

arr2 = []
n = int(input("Enter the number of elements: "))
for i in range(n):
    arr2.append(int(input("Enter the element: ")))

IsSubset = True

for i in arr2:
    if i not in arr1:
        IsSubset = False
        break

if IsSubset:
    print("arr2 is a subset of arr1")
else:
    print("arr2 is not a subset of arr1")
