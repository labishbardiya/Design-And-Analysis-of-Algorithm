// Implement hashing using linear probing. Take the size of the hash table and the elements
// to be input from the user. The hash function is h(x) = (x+2) mod size. When the array is full
// and no more elements can be accommodated, throw the appropriate error.

#include <stdio.h>
#include <stdlib.h>

#define EMPTY -1

int hashFun(int x, int size) {
    return (x + 2) % size;
}

void insert(int hashTable[], int size, int element) {
    int index = hashFun(element, size);
    int originalIndex = index;
    while (hashTable[index] != EMPTY) {
        index = (index + 1) % size;
        if (index == originalIndex) {
            printf("Error: Hash table is full, cannot insert %d\n", element);
            return;
        }
    }
    hashTable[index] = element;
}

void displayHashTable(int hashTable[], int size) {
    for (int i = 0; i < size; i++) {
        if (hashTable[i] != EMPTY) {
            printf("Index %d: %d\n", i, hashTable[i]);
        } else {
            printf("Index %d: EMPTY\n", i);
        }
    }
}

int main() {
    int size, numElements, element;

    printf("Enter the size of the hash table: ");
    scanf("%d", &size);

    int *hashTable = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; i++) {
        hashTable[i] = EMPTY;
    }

    printf("Enter the number of elements to be inserted: ");
    scanf("%d", &numElements);

    for (int i = 0; i < numElements; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &element);
        insert(hashTable, size, element);
    }

    printf("Hash table:\n");
    displayHashTable(hashTable, size);

    free(hashTable);
    return 0;
}
