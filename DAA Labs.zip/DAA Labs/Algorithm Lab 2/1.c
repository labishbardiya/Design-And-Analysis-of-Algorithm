// Using Fermat’s little theorem find if a given positive integer, n is prime. Note: Finding the
// exponent should have a complexity of log n so that the complexity of your code is O(log2n).
// Input: 5 Output: true
// Input: 12 Output: false
// Input: any Carmichael ‘s number Output: ?

#include <stdio.h>

int main() {
    int x, y = 2, ans = 1;
    printf("enter p: ");
    scanf("%d", &x);

    int b = x - 1;

    while (b > 0) {
        if (b % 2 == 1) {
            ans = (ans * y) % x;
        }
        y = (y * y) % x;
        b /= 2;
    }

    if (ans == 1) {
        printf("True");
    } else {
        printf("False");
    }

    return 0;
}
