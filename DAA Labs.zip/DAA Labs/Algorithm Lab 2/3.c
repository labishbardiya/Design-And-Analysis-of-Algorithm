// Implement hashing using chaining. Take the size of the hash table and the elements to be
// input from the user. Use the same hash function as above. Note: while chaining, the latest
// element to be chained will be the first element of the linked list.

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node* next;
};

struct HashTable {
    int size;
    struct Node** table;
};

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

struct HashTable* createHashTable(int size) {
    struct HashTable* hashTable = (struct HashTable*)malloc(sizeof(struct HashTable));
    hashTable->size = size;
    hashTable->table = (struct Node**)malloc(size * sizeof(struct Node*));
    for (int i = 0; i < size; i++) {
        hashTable->table[i] = NULL;
    }
    return hashTable;
}

int hashFunction(int key, int size) {
    return key % size;
}

void insert(struct HashTable* hashTable, int data) {
    int index = hashFunction(data, hashTable->size);
    struct Node* newNode = createNode(data);
    newNode->next = hashTable->table[index];
    hashTable->table[index] = newNode;
}

void display(struct HashTable* hashTable) {
    for (int i = 0; i < hashTable->size; i++) {
        struct Node* temp = hashTable->table[i];
        printf("Index %d: ", i);
        while (temp) {
            printf("%d -> ", temp->data);
            temp = temp->next;
        }
        printf("NULL\n");
    }
}

int main() {
    int size, n, data;

    printf("Enter the size of the hash table: ");
    scanf("%d", &size);

    struct HashTable* hashTable = createHashTable(size);

    printf("Enter the number of elements to be inserted: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Enter element %d: ", i + 1);
        scanf("%d", &data);
        insert(hashTable, data);
    }

    display(hashTable);

    return 0;
}
