# For a given one-dimensional array, find the min and max using divide and conquer strategy. Express the time complexity of your code in terms of a recurrence relation. What is the complexity using master’s theorem.

def find_min_max(arr, low, high):
    if low == high:
        return arr[low], arr[low]
    elif high == low + 1:
        if arr[low] < arr[high]:
            return arr[low], arr[high]
        else:
            return arr[high], arr[low]
    else:
        mid = (low + high) // 2
        min1, max1 = find_min_max(arr, low, mid)
        min2, max2 = find_min_max(arr, mid + 1, high)
        return min(min1, min2), max(max1, max2)

arr = [3, 5, 1, 2, 4, 8]
low = 0
high = len(arr) - 1
min_val, max_val = find_min_max(arr, low, high)
print(f"Minimum value: {min_val}")
print(f"Maximum value: {max_val}")

# time complexity T(n) = 2T(n/2)
# using master's theorem, T(n) = O(n)
