# Implement binary search on a sorted array of strings to find if a given string exists in the array.

arr = ["apo", "bac", "cod", "deb", "eed", "ghi", "hja", "ilp"]
x = "bac"

low = 0
high = len(arr) - 1
mid = 0

while low <= high:
    mid = (high + low) // 2

    if arr[mid] < x:
        low = mid + 1
    elif arr[mid] > x:
        high = mid - 1
    else:
        print(f"Element is present at index {mid}")
        break
else:
    print("Element is not present in array")
