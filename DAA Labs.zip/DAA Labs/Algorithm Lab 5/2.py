# Write a program for prim’s algorithm. Test it for the input:
# graph = {
# '0':{'1':10, '3':30, '4':100},
# '1': {'0': 10, '2':50},
# '2': {'1': 50, '3': 20, '4': 10},
# '3': {'0': 30, '2': 20, '4': 60},
# '4': {'0': 100, '2': 10,'3':60}
# }

import heapq

def prim(graph, start):
    edges = []
    visited = set()
    min_heap = [(0, start, None)]

    while min_heap:
        cost, current_node, previous_node = heapq.heappop(min_heap)
        if current_node not in visited:
            visited.add(current_node)
            if previous_node is not None:
                edges.append((previous_node, current_node, cost))

            for neighbor, weight in graph[current_node].items():
                if neighbor not in visited:
                    heapq.heappush(min_heap, (weight, neighbor, current_node))

    return edges

# testing the algorithm
graph = {
    '0': {'1': 10, '3': 30, '4': 100},
    '1': {'0': 10, '2': 50},
    '2': {'1': 50, '3': 20, '4': 10},
    '3': {'0': 30, '2': 20, '4': 60},
    '4': {'0': 100, '2': 10, '3': 60}
}

edges = prim(graph, '0')
print("Minimum Spanning Tree:", edges)  # printing the resulting edges
