# Write a program to implement weighted union find.

# Function to find the root of an element i
def find(parent, i):
    if parent[i] == i:
        return i
    else:
        # Path compression heuristic
        parent[i] = find(parent, parent[i])
        return parent[i]

# Function to perform union of two subsets x and y
def union(parent, rank, weight, x, y):
    root_x = find(parent, x)
    root_y = find(parent, y)

    if root_x != root_y:
        # Attach smaller rank tree under root of higher rank tree
        if rank[root_x] > rank[root_y]:
            parent[root_y] = root_x
            weight[root_x] += weight[root_y]
        elif rank[root_x] < rank[root_y]:
            parent[root_x] = root_y
            weight[root_y] += weight[root_x]
        else:
            # If ranks are same, then make one as root and increment its rank by one
            parent[root_y] = root_x
            weight[root_x] += weight[root_y]
            rank[root_x] += 1

# Function to get the weight of the component containing element i
def get_component_weight(parent, weight, i):
    root = find(parent, i)
    return weight[root]

# Example usage
n = 5  # Number of elements
parent = [i for i in range(n)]  # Initialize parent array
rank = [0] * n  # Initialize rank array
weight = [1] * n  # Initial weight of each element

# Perform union operations
union(parent, rank, weight, 0, 1)
union(parent, rank, weight, 1, 2)
union(parent, rank, weight, 3, 4)

# Get and print the weight of the components
print(get_component_weight(parent, weight, 0))  # Output: 3
print(get_component_weight(parent, weight, 3))  # Output: 2