def get_dimensions():
    p = list(map(int, input("Enter matrix dimensions: ").split()))
    return p

def matrix_chain_top_down(p):
    n = len(p) - 1
    m = [[-1]*n for _ in range(n)]
    s = [[-1]*n for _ in range(n)]

    def lookup(i, j):
        if m[i][j] != -1:
            return m[i][j]
        if i == j:
            m[i][j] = 0
        else:
            m[i][j] = float('inf')
            for k in range(i, j):
                q = lookup(i, k) + lookup(k+1, j) + p[i]*p[k+1]*p[j+1]
                if q < m[i][j]:
                    m[i][j] = q
                    s[i][j] = k
        return m[i][j]

    lookup(0, n-1)
    return m, s

def print_parenthesis(s, i, j):
    if i == j:
        print(f"A{i+1}", end="")
    else:
        print("(", end="")
        print_parenthesis(s, i, s[i][j])
        print_parenthesis(s, s[i][j] + 1, j)
        print(")", end="")

if __name__ == "__main__":
    p = get_dimensions()
    m, s = matrix_chain_top_down(p)
    print("Minimum number of multiplications:", m[0][-1])
    print("Optimal parenthesization: ", end="")
    print_parenthesis(s, 0, len(p)-2)
