#  Write a program in python to implement:

# a. Quick find
# b. Quick Union

def quick_find(n):
    id = list(range(n))

    def connected(p, q):
        return id[p] == id[q]

    def union(p, q):
        pid = id[p]
        qid = id[q]
        for i in range(len(id)):
            if id[i] == pid:
                id[i] = qid

    return connected, union

def quick_union(n):
    id = list(range(n))

    def root(i):
        while i != id[i]:
            i = id[i]
        return i

    def connected(p, q):
        return root(p) == root(q)

    def union(p, q):
        rootP = root(p)
        rootQ = root(q)
        id[rootP] = rootQ

    return connected, union
