// Write a program in C to implement basic interval scheduling. Each request
// has a start and finish time stored in an array. Assume that the arrays are already
// sorted on finish time.

#include <stdio.h>

void iS(int st[], int fi[], int len) {
    int i = 0, j;
    printf("selected intervals are:\n");
    printf("(%d, %d)\n", st[i], fi[i]);

    for (j = 1; j < len; j++) {
        if (st[j] >= fi[i]) {
            printf("(%d, %d)\n", st[j], fi[j]);
            i = j;
        }
    }
}

int main() {
    int st[] = {1, 1, 3, 3, 5, 4};
    int fi[] = {3, 4, 5, 4, 6, 8};
    int len = sizeof(st) / sizeof(st[0]);
    iS(st, fi, len);

    return 0;
}
