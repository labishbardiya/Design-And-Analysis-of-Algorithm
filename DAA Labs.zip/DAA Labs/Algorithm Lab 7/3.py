def min_guards(items):
    items.sort()
    
    n = len(items)
    guards = 0
    i = 0
    
    while i < n:
        guard_position = items[i] + 1
        while i < n and items[i] <= guard_position + 1:
            i += 1
        guards += 1
        
    return guards

items = [1, 2, 3, 4]
print("The number of guards needed is:", min_guards(items))
