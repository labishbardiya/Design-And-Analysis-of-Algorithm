# For a given set of points in a 2D plane, find the distance between the closest pair of points. Write a program for Q1 using divide and conquer programming paradigm. Express the complexity in terms of a recurrence relation and apply master’s theorem (if possible) to find the final complexity of your algorithm.

import math

points = [(2,3), (12,30), (40,50), (5,1), (12,10), (3,4)]

def distance(p1, p2):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

def brute_force(points):
    min_dist = float('inf')
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            min_dist = min(min_dist, distance(points[i], points[j]))

    return min_dist

def sort_by_x(point):
    return point[0]

def sort_by_y(point):
    return point[1]

points_sorted = sorted(points, key=sort_by_x)

def closest_pair_rec(points_sorted):
    if len(points_sorted) <= 3:
        return brute_force(points_sorted)

    mid = len(points_sorted) // 2
    mid_point = points_sorted[mid]

    d_left = closest_pair_rec(points_sorted[:mid])
    d_right = closest_pair_rec(points_sorted[mid:])
    d = min(d_left, d_right)

    strip = [p for p in points_sorted if abs(p[0] - mid_point[0]) < d]
    strip.sort(key=sort_by_y)

    strip_dist = float('inf')
    for i in range(len(strip)):
        for j in range(i + 1, len(strip)):
            if strip[j][1] - strip[i][1] >= d:
                break
            strip_dist = min(strip_dist, distance(strip[i], strip[j]))

    return min(d, strip_dist)

closest_distance = closest_pair_rec(points_sorted)
print("The smallest distance is:", closest_distance)
