# Find the maximum distance in an array (This can be solved using min-max problem by an additional step of taking their difference).Write a program for Q2 using divide and conquer programming paradigm. Express the complexity in terms of a recurrence relation and apply master’s theorem (if possible) to find the final complexity of your algorithm.

def f_minimax(arr, low, high):
    if low == high:
        return arr[low], arr[low]

    if high == low + 1:
        return (min(arr[low], arr[high]), max(arr[low], arr[high]))

    mid = (low + high) // 2

    left_min, left_max = f_minimax(arr, low, mid)
    right_min, right_max = f_minimax(arr, mid + 1, high)

    return min(left_min, right_min), max(left_max, right_max)

arr = [15, 16, 2, 1, 3, 2]

min_val, max_val = f_minimax(arr, 0, len(arr) - 1)
max_dis = max_val - min_val

print("Max Distance:", max_dis)
